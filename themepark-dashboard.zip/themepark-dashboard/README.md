# 테마파크 인사이트 대시보드 🎢

모바일 최적화 테마파크/워터파크 뉴스 + 가격비교 대시보드

---

## 📁 폴더 구조

```
themepark-dashboard/
├── backend/
│   ├── server.js        ← 메인 서버 (뉴스·가격 API)
│   ├── prices.js        ← 가격 데이터 (수정 포인트!)
│   ├── .env.example     ← 환경변수 예시
│   └── package.json
└── frontend/
    └── public/
        └── index.html   ← 앱 화면 (수정 포인트!)
```

---

## 🚀 1단계: 로컬 실행 (내 컴퓨터에서 테스트)

### 준비물
- Node.js 설치 (https://nodejs.org → LTS 버전 설치)
- Anthropic API 키 (https://console.anthropic.com)

### 실행 순서

```bash
# 1. 백엔드 폴더로 이동
cd themepark-dashboard/backend

# 2. 패키지 설치
npm install

# 3. 환경변수 파일 만들기
cp .env.example .env

# 4. .env 파일 열어서 API 키 입력
# ANTHROPIC_API_KEY=sk-ant-여기에_실제_키_입력

# 5. 서버 시작
node server.js

# 브라우저에서 http://localhost:3000 접속!
```

---

## 🌐 2단계: 공유 가능한 링크 만들기 (배포)

### 방법 A: Railway (가장 쉬움, 무료 플랜 있음) ⭐ 추천

1. https://railway.app 접속 → GitHub 로그인
2. "New Project" → "Deploy from GitHub repo"
3. 이 프로젝트 GitHub에 업로드 후 연결
4. 환경변수 설정:
   - `ANTHROPIC_API_KEY` = 실제 API 키
   - `PORT` = 3000
5. 배포 완료 → `https://xxx.railway.app` 링크 생성!

**PC에서도, 핸드폰에서도 이 링크로 접속 가능**

---

### 방법 B: Render (무료 플랜, 느릴 수 있음)

1. https://render.com 접속 → GitHub 로그인
2. "New Web Service" → GitHub 연결
3. 설정:
   - Build Command: `cd backend && npm install`
   - Start Command: `cd backend && node server.js`
   - 환경변수: `ANTHROPIC_API_KEY` 입력
4. 배포 → `https://xxx.onrender.com` 링크 생성

---

### 방법 C: Vercel (프론트엔드 무료, 백엔드는 serverless)

백엔드가 있어서 Vercel은 추가 설정이 필요합니다.
Railway나 Render를 먼저 추천드립니다.

---

### 방법 D: VPS 서버 (AWS/GCP/네이버클라우드 등)

```bash
# 서버에 접속 후
git clone [이 프로젝트]
cd themepark-dashboard/backend
npm install
cp .env.example .env
# .env 수정
npm install -g pm2
pm2 start server.js --name themepark
pm2 save
```

---

## ✏️ 3단계: 수정 방법

### 📌 가격 수정 (파크 공식 홈페이지 확인 후)

파일: `backend/prices.js`

```javascript
// 예: 웅진플레이도시 종일권 가격 변경
woojin: {
  tickets: [
    {
      id: "day",
      label: "종일권",
      prices: { adult: 60000, child: 60000 },  // ← 여기 숫자 변경
    }
  ]
}
```

수정 후 서버 재시작:
```bash
# 로컬: Ctrl+C 후 node server.js
# Railway: GitHub push 하면 자동 재배포
# PM2: pm2 restart themepark
```

---

### 📌 새 파크 추가

`backend/prices.js`에 새 항목 추가:
```javascript
new_park: {
  name: "새 파크 이름",
  homepageUrl: "https://...",
  currentSeason: "시즌명",
  tickets: [...],
  channelDiscounts: {...}
}
```

`frontend/public/index.html`의 `PARKS` 배열에도 추가:
```javascript
{key:'new_park', name:'새 파크 이름', icon:'🎪', cat:'워터파크', loc:'경기 xx'},
```

---

### 📌 UI 수정

파일: `frontend/public/index.html`

- 색상: 파일 상단 `:root` 섹션의 CSS 변수 변경
- 레이아웃: 각 섹션 HTML 직접 수정
- 파크 목록 순서: `const PARKS = [...]` 배열 순서 변경

---

## 🔄 운영 팁

### 가격 업데이트 주기
- **시즌 변경 시** (봄→여름→골드→하이): `prices.js` 필수 업데이트
- 각 파크 공식 홈페이지 북마크 → 분기별 확인 권장

### 뉴스 캐시
- 기본 30분 캐시 (`.env`의 `NEWS_CACHE_TTL`으로 조정)
- 앱에서 "AI 뉴스 새로고침" 버튼으로 강제 갱신 가능

### API 키 비용
- Claude API: 뉴스 검색 1회당 약 $0.001~0.003 (매우 저렴)
- 캐시 덕분에 30분에 1번만 실제 API 호출

---

## 🆘 문제 해결

| 문제 | 해결 |
|------|------|
| 뉴스가 안 나와요 | `.env`의 `ANTHROPIC_API_KEY` 확인 |
| 가격이 이상해요 | `prices.js`에서 해당 파크 직접 수정 |
| 서버가 안 켜져요 | `npm install` 다시 실행 |
| 링크가 안 열려요 | Railway/Render 배포 로그 확인 |

---

## 📞 수정 도움

이후 수정이 필요하면 Claude에게 다음과 같이 요청하세요:

> "themepark-dashboard의 prices.js에서 웅진플레이도시 가격을 xx원으로 바꿔줘"
> "index.html에 xx 기능 추가해줘"
> "새 파크 xxx 추가해줘"

---

*마지막 업데이트: 2026년 4월 3일*
